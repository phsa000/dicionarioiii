//audio
function playAudio(audioId) {
    document.getElementById(audioId).play();
  }

// array
const palavras = document.querySelectorAll('.col'); // ou selecione os elementos de outra maneira
const modal_conteudo = [
  { Palavra: 'Ocorrência', Texto: 'Um evento ou incidente que acontece em determinado momento ou lugar.\n"Um dia, ocorreu algo que não era normal."' },
  { Palavra: 'Necessário', Texto: 'Algo essencial ou imprescindível para satisfazer uma condição ou atender a uma exigência.\n"abrir um negócio que para os moradores locais parecia ser muito necessário"' },
  { Palavra: 'Conveniência', Texto: ' qualidade de ser adequado, útil ou favorável para uma situação específica.\n"Felipe continuou e teve ações não muito convenientes."' },
  { Palavra: 'Acomodar', Texto: 'Ajustar ou adaptar para atender às necessidades ou demandas de algo ou alguém.\n"porque a instalação não era preparada para acomodar algo daquele tamanho."' },
  { Palavra: 'Burocracia', Texto: 'Um sistema administrativo caracterizado por regras, procedimentos e papelada excessivos, muitas vezes visto como complicado e demorado.\n"enfrentou problemas por causa da burocracia que existia para conseguir o alvará."' },
  { Palavra: 'Empreendedor', Texto: 'Pessoa que inicia e gerencia negócios.\n"um empresário chamado Felipe decidiu abrir um negócio que para os moradores locais parecia ser muito necessário"' },
  { Palavra: 'Embaraçoso', Texto: 'Causando desconforto, constrangimento ou vexame.\n"Um navio muito maior que os outros chegou no porto, o que causou uma situação embaraçosa,"' },
  { Palavra: 'Fenômeno', Texto: 'Um fato ou evento observável e notável que ocorre naturalmente ou como resultado de uma ação específica.\n"Esse negócio virou um fenômeno na cidade"' },
  { Palavra: 'Malicioso', Texto: 'Travesso, inclinado a praticar travessuras ou comportamentos levados.\n"A malícia que tinha no seu sorriso"' },
  { Palavra: 'Manutenção', Texto: 'Ação de preservar, cuidar e realizar reparos necessários para manter algo em bom estado ou funcionamento.\n"Ele percebeu que a manutenção de embarcações de pescas era algo comum na região"' },
];

//abre
const abreModal = (index) => {
    const modal = document.getElementById('myModal');
    modal.style.display = 'block';
    janela_palavra_titulo.textContent = modal_conteudo[index].Palavra;
    janela_palavra_texto.textContent = modal_conteudo[index].Texto;
};

//muda palavra
for (const palavra of palavras) {
  palavra.addEventListener('click', () => {
      const index = Array.from(palavras).indexOf(palavra);
      abreModal(index);
  });
}

//fecha
const fecharModal = () => {
    const modal = document.getElementById('myModal');
    modal.style.display = 'none';
};

//clica fora
window.addEventListener('click', (event) => {
    const modal = document.getElementById('myModal');
    if (event.target == modal) {
        fecharModal();
    }
});